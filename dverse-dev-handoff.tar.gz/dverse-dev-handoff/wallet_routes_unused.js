// wallet_routes.js — TURNKEY wiring for wallet + WFF.
// In your server entry (e.g. index.js / server.js / app.js), add ONE line AFTER
// `db` and `app` and the auth middleware exist:
//
//     const wallet = require("./wallet_routes")(app, db, authMiddleware);
//
// Then in your existing unlock/donate/gacha routes use `wallet.spend(...)`.
//
// INTEGRATION POINTS (the only things to match to your schema):
//   - table `chapters(book_id, seq, tier)`   -> getChapterTier
//   - table `unlocks(user_id, book_id, chapter_seq, source)` -> grantOwnership
//   If your table/column names differ, edit ONLY the two SQL strings below.
//   If those tables don't exist yet, STOP and ask — do not guess.

const wallet = require("./wallet");
const { migrate: wffMigrate, createWffRoute } = require("./wff");

module.exports = function wire(app, db, auth) {
  // schema (idempotent — safe to run every boot)
  wallet.migrate(db);
  wffMigrate(db);

  // faucet amounts decided SERVER-SIDE (client cannot send the number)
  const FAUCETS = {
    "mission:read": 3, "mission:comment": 4, "mission:vote": 4, "mission:share": 5,
  };

  const W = wallet.createWalletRoutes(db);
  app.get("/wallet/balance", auth, W.balance);
  app.post("/wallet/faucet", auth, W.faucet(FAUCETS));

  const wffDeps = {
    getChapterTier: (bid, seq) => {
      const row = db.prepare("SELECT tier FROM chapters WHERE book_id=? AND seq=?").get(bid, seq);
      return row && row.tier;
    },
    grantOwnership: (uid, bid, seq) =>
      db.prepare(
        "INSERT OR IGNORE INTO ownership (user_id, book_id, seq, source) VALUES (?,?,?,'wff')"
      ).run(uid, bid, seq),
  };
  app.post("/wff/claim", auth, createWffRoute(db, wffDeps));

  // expose for use inside your existing routes:
  //   const r = wallet.spend(db, req.userId, priceCoin, `unlock ${bid}#${seq}`);   // chapter
  //   const r = wallet.spend(db, req.userId, amt, "donate", true);                 // donate (paid only)
  //   wallet.grant(db, userId, coins, "paid", "topup:vnpay");                      // after IPN
  return wallet;
};
