'use strict';
/**
 * wallet_paidonly_test.js — 4 cases cho nhánh paidOnly
 * Chạy: node wallet_paidonly_test.js
 * Kết quả mong đợi: 4 PASS
 */
const Module = require('module');
const path = require('path');
const Database = require('better-sqlite3');
const db = new Database(':memory:');

// Minimal schema
db.exec(`
  CREATE TABLE wallet (user_id TEXT PRIMARY KEY, coin_free INTEGER NOT NULL DEFAULT 0, coin_paid INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL);
  CREATE TABLE ledger (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, delta_free INTEGER, delta_paid INTEGER, kind TEXT, label TEXT, ref TEXT, idem_key TEXT, created_at INTEGER);
  CREATE TABLE idempotency (key TEXT PRIMARY KEY, user_id TEXT, scope TEXT, response TEXT, created_at INTEGER);
`);

// Inject stubs vào require cache
const idemPath = path.resolve(__dirname, 'src/services/idempotency.js');
require.cache[path.resolve(__dirname, 'src/db/index.js')] = {
  id: 'db', filename: 'db', loaded: true, exports: { db }
};
require.cache[idemPath] = {
  id: idemPath, filename: idemPath, loaded: true,
  exports: { getStored: () => null, store: () => {} }
};

const wallet = require('./src/services/wallet');

let pass = 0; let fail = 0;
function assert(desc, cond) {
  if (cond) { console.log('  PASS:', desc); pass++; }
  else       { console.error('  FAIL:', desc); fail++; }
}

// Setup: user có coin_free=100, coin_paid=50
db.prepare("INSERT INTO wallet (user_id,coin_free,coin_paid,updated_at) VALUES ('u1',100,50,?)").run(Date.now());

console.log('\n=== wallet paidOnly tests ===\n');

// Case 1: paidOnly=true, đủ coin_paid (50) → OK, coin_free không bị trừ
const r1 = wallet.spend('u1', 30, { kind: 'test', paidOnly: true });
assert('paidOnly spend 30 từ paid=50 → ok', r1.ok === true);
assert('paidOnly: coin_free vẫn 100 (không bị trừ)', r1.balance && r1.balance.coinFree === 100);

// Case 2: paidOnly=true, paid còn 20, cần 30 → INSUFFICIENT
const r2 = wallet.spend('u1', 30, { kind: 'test', paidOnly: true });
assert('paidOnly spend 30 từ paid=20 → INSUFFICIENT', r2.ok === false && r2.code === 'INSUFFICIENT');

// Case 3: normal spend 50 (no paidOnly) → tiêu free trước, free=100 paid=20
const r3 = wallet.spend('u1', 50, { kind: 'test' });
assert('normal spend 50: free trước → coinFree=50, coinPaid=20', r3.ok === true && r3.balance.coinFree === 50 && r3.balance.coinPaid === 20);

// Case 4: drain hết paid (còn 20), rồi paidOnly spend 1 → INSUFFICIENT dù free còn 50
wallet.spend('u1', 20, { kind: 'test', paidOnly: true }); // drain paid về 0
const r4 = wallet.spend('u1', 1, { kind: 'test', paidOnly: true });
assert('paidOnly spend 1, paid=0 → INSUFFICIENT (free không dùng)', r4.ok === false && r4.code === 'INSUFFICIENT');

console.log(`\n=== Kết quả: ${pass} PASS / ${fail} FAIL ===\n`);
process.exit(fail > 0 ? 1 : 0);
