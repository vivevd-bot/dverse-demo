# DVERSE — Dev Handoff Package
**DND Group | Chuẩn bị cho team dev nội bộ**

## Cấu trúc package

```
/frontend
  dverse-wired.html       ← Demo app đầy đủ (1.1MB, React 18 UMD, 10 truyện thật)

/backend
  server.js               ← API server chính (Node.js + Express)
  core.js                 ← Business logic
  db.js                   ← Database layer (SQLite)
  seed.js                 ← Seed data
  api-client.js           ← Client helper
  package.json            ← Dependencies
  railway.json            ← Railway deploy config
  README.md               ← Hướng dẫn setup
  DEPLOY.md               ← Hướng dẫn deploy

/docs
  DVERSE-Handoff-DevTeam.docx      ← Tài liệu chính (kiến trúc, features, API, roadmap)
  DVERSE-Tech-Review-2026-06-23.docx   ← Tech review chi tiết
  DVERSE_Qidian_Upgrade_Spec.docx  ← Spec nâng cấp theo chuẩn Qidian

/screenshots
  dverse_test_*.png       ← Screenshots toàn bộ màn hình demo

```

## Quick Start

### Chạy frontend (local)
```
# Mở file trực tiếp trong browser
open frontend/dverse-wired.html
```

### Chạy backend (local)
```
cd backend
npm install
NODE_ENV=dev DVERSE_BILLING=mock node server.js
# → http://localhost:4200
# → OTP dev: 000000
```

### Live demo
- Frontend: https://vivevd-bot.github.io/dverse-demo/
- Backend API: https://dverse-backend-production.up.railway.app/health

## Timeline
- Beta: T9/2026
- Full Launch: T11/2026
- SEA Expansion: 2027+
